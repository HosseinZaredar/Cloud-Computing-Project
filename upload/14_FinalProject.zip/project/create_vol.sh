kubectl apply -f k8s/persist_vol.yaml
kubectl apply -f k8s/persist_claim.yaml